﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion6.Ejercicio4
{
    //Crear un programa nos pida introducir 10 números enteros. 
    //esos valores los introduciremos en un Listado y  mostraremos el 
    //numero mayor y menor, consultando los valores en el Listado.
    class Program
    {
        static void Main(string[] args)
        {
            List<int> listadoEnteros = new List<int>();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Introduce un numero");
                int numero = int.Parse(Console.ReadLine());

                listadoEnteros.Add(numero);
            }

            Console.WriteLine($"El numero mayor en el listado es: {listadoEnteros.Max()}");
            Console.WriteLine($"El numero menor en el listado es: {listadoEnteros.Min()}");
            Console.ReadKey();
        }
    }
}
