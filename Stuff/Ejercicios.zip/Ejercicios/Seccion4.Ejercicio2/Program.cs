﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio2
{
  //  Crear una calculadora , usando funciones de suma, resta, multiplicación y división.
  //  *Se creara un menú por consola, de la siguiente forma:
  //       1- Suma
  //       2- Resta
  //       3- Multiplicación
  //       4- División
  //  Seleccione la opción:
  //dependiendo de la selección, se pedirán 2 números, y usando las funciones creadas, devolverá el resultado por consola
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** Calculadora ***");
            Console.WriteLine("1 -Sumar ");
            Console.WriteLine("2 - Restar");
            Console.WriteLine("3 - Multiplicar");
            Console.WriteLine("4 - Dividir");
            Console.WriteLine("0 - Salir");
            Console.WriteLine("Selecciona una opcion");
            string opcion = Console.ReadLine();

            Console.WriteLine("Introduce un numero");
            int numero1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Introduce otro numero");
            int numero2 = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case "1": Console.WriteLine($"El resultado es: {Sumar(numero1, numero2)}");
                    break;
                case "2":
                    Console.WriteLine($"El resultado es: {Restar(numero1, numero2)}");
                    break;
                case "3":
                    Console.WriteLine($"El resultado es: {Multiplicar(numero1, numero2)}");
                    break;
                case "4":
                    Console.WriteLine($"El resultado es: {Dividir(numero1, numero2)}");
                    break;
                case "0":
                    break;
                default:
                    break;
            }

            Console.ReadKey();

        }

        public static int Sumar(int num1,int num2)
        {
            return num1 + num2;
        }

        public static int Restar(int num1, int num2)
        {
            return num1 - num2;
        }

        public static int Multiplicar(int num1, int num2)
        {
            return num1 * num2;
        }

        public static float Dividir(int num1, int num2)
        {
            return num1 / num2;
        }

        
    }
}
