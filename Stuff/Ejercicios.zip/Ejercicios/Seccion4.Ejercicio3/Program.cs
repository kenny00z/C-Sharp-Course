﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio3
{
    //Se creara un programa que mediante funciones, 
    //nos ayude a desglosar un importe introducido por consola, 
    //en el numero mínimo posible de billetes y monedas.
    class Program
    {

        static void Main(string[] args)
        {
            

            Console.WriteLine("Introduce un importe");
            var importe = double.Parse(Console.ReadLine());
            int billetes500 = CuantosBilletesDe500(importe);

            //billetes:
            //500€  100€ 50€ 20€ 10€ 5€ 
            //monedas
            //2€ 1€ 50cent 20cent 10cent 5cent 1 2cent 1cent

            if (billetes500 > 0)
            {
                importe = importe - (500 * billetes500);
            }

            int billetes200 = CuantosBilletesDe200(importe);

            if(billetes200 > 0)
            {
                importe = importe - (200 * billetes200);
            }

            int billetes100 = CuantosBilletesDe100(importe);

            if (billetes100 > 0)
            {
                importe = importe - (100 * billetes100);
            }


            int billetes50 = CuantosBilletesDe50(importe);

            if (billetes50 > 0)
            {
                importe = importe - (50 * billetes50);
            }

            int billetes20 = CuantosBilletesDe20(importe);

            if (billetes20 > 0)
            {
                importe = importe - (20 * billetes20);
            }

            int billetes10 = CuantosBilletesDe10(importe);

            if (billetes10 > 0)
            {
                importe = importe - (10 * billetes10);
            }

            int billetes5 = CuantosBilletesDe5(importe);

            if (billetes5 > 0)
            {
                importe = importe - (5 * billetes5);
            }

            int monedas2 = CuantasMonedasDe2(importe);

            if (monedas2 > 0)
            {
                importe = importe - (2 * monedas2);
            }

            int monedas1 = CuantasMonedasDe1(importe);

            if (monedas1 > 0)
            {
                importe = importe - (1 * monedas1);
            }

            int monedas05 = CuantasMonedasDe50Cent(importe);

            if (monedas05 > 0)
            {
                importe = importe - (0.5 * monedas05);
            }

            int monedas02 = CuantasMonedasDe20Cent(importe);

            if (monedas02 > 0)
            {
                importe = importe - (0.2 * monedas02);
            }

            int monedas01 = CuantasMonedasDe10Cent(importe);

            if (monedas01 > 0)
            {
                importe = importe - (0.1 * monedas01);
            }

            int monedas005 = CuantasMonedasDe5Cent(importe);

            if (monedas005 > 0)
            {
                importe = importe - (0.05 * monedas005);
            }

            int monedas002 = CuantasMonedasDe2cent(importe);

            if (monedas002 > 0)
            {
                importe = importe - (0.02 * monedas002);
            }

            int monedas001 = CuantasMonedasDe1Cent(importe);

            if (monedas001 > 0)
            {
                importe = importe - (0.01 * monedas001);
            }

            Console.WriteLine($"Hay {billetes500} billetes de 500");
            Console.WriteLine($"Hay {billetes200} billetes de 200");
            Console.WriteLine($"Hay {billetes100} billetes de 100");
            Console.WriteLine($"Hay {billetes50} billetes de 50");
            Console.WriteLine($"Hay {billetes20} billetes de 20");
            Console.WriteLine($"Hay {billetes10} billetes de 10");
            Console.WriteLine($"Hay {billetes5} billetes de 5");
            Console.WriteLine($"Hay {monedas2} monedas de 2");
            Console.WriteLine($"Hay {monedas1} monedas de 1");
            Console.WriteLine($"Hay {monedas05} monedas de 50 centimos");
            Console.WriteLine($"Hay {monedas02} monedas de 20 centimos");
            Console.WriteLine($"Hay {monedas01} monedas de 10 centimos");
            Console.WriteLine($"Hay {monedas005} monedas de 5 centimos");
            Console.WriteLine($"Hay {monedas002} monedas de 2 centimos");
            Console.WriteLine($"Hay {monedas001} monedas de 1 centimos");

            Console.ReadKey();



        }

        public static int CuantosBilletesDe500(double importe)
        {
            if(importe >= 500)
            {
                return (int)(importe / 500);
            }

            return 0;
        }

        public static int CuantosBilletesDe200(double importe)
        {
            if (importe >= 200)
            {
                return (int)(importe / 200);
            }

            return 0;
        }

        public static int CuantosBilletesDe100(double importe)
        {
            if (importe >= 100)
            {
                return (int)(importe / 100);
            }

            return 0;
        }

        public static int CuantosBilletesDe50(double importe)
        {
            if (importe >= 50)
            {
                return (int)(importe / 50);
            }

            return 0;
        }

        public static int CuantosBilletesDe20(double importe)
        {
            if (importe >= 20)
            {
                return (int)(importe / 20);
            }

            return 0;
        }

        public static int CuantosBilletesDe10(double importe)
        {
            if (importe >= 10)
            {
                return (int)(importe / 10);
            }

            return 0;
        }

        public static int CuantosBilletesDe5(double importe)
        {
            if (importe >= 5)
            {
                return (int)(importe / 5);
            }

            return 0;
        }

        public static int CuantasMonedasDe2(double importe)
        {
            if (importe >= 2)
            {
                return (int)(importe / 2);
            }

            return 0;
        }

        public static int CuantasMonedasDe1(double importe)
        {
            if (importe >= 1)
            {
                return (int)(importe / 1);
            }

            return 0;
        }

        public static int CuantasMonedasDe50Cent(double importe)
        {
            if (importe >= 0.5)
            {
                return (int)(importe / 0.5);
            }

            return 0;
        }

        public static int CuantasMonedasDe20Cent(double importe)
        {
            if (importe >= 0.20)
            {
                return (int)(importe / 0.2);
            }

            return 0;
        }

        public static int CuantasMonedasDe10Cent(double importe)
        {
            if (importe >= 0.1)
            {
                return (int)(importe / 200);
            }

            return 0;
        }
        public static int CuantasMonedasDe5Cent(double importe)
        {
            if (importe >= 0.05)
            {
                return (int)(importe / 0.05);
            }

            return 0;
        }
        public static int CuantasMonedasDe2cent(double importe)
        {
            if (importe >= 0.02)
            {
                return (int)(importe / 0.02);
            }

            return 0;
        }
        public static int CuantasMonedasDe1Cent(double importe)
        {
            if (importe >= 0.01)
            {
                return (int)(importe / 0.01);
            }

            return 0;
        }
    }
}
