﻿using System;

namespace Seccion2.Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola mi nombre es Alberto Picazo");
        }
    }
}
