﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio4
{
    //Crear una Clase Vehículo, con las propiedades , Ruedas, puertas privadas, 
    //crear 3 constructores para asignar los valores de las propiedades, 
    //el constructor por defecto y 2 constructores mas que creas convenientes.
    class Program
    {
        static void Main(string[] args)
        {

            Vehiculo vehiculo1 = new Vehiculo(); //0 puertas y ruedas
            Vehiculo vehiculo2 = new Vehiculo(4); //4 puertas
            Vehiculo vehiculo3 = new Vehiculo(4, 3);  //4 ruedas 3 puertas

        }
    }
}
