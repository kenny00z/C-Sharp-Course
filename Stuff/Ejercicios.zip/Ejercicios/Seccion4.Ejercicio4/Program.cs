﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio4
{
    //Crear un programa que lea una letra tecleada por el usuario y 
    //diga si se trata de una vocal, una cifra numérica o una consonante 
    //(realizar obligatoriamente 3 funciones, "EsNumero", "EsVocal", "EsConsonante").
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("introduce un caracter");
            var letra = Console.ReadKey();
            var letraKey = letra.KeyChar;

            if (EsNumero(letraKey))
            {
                Console.WriteLine("Es un numero");
            }
            else
            {
                if (EsVocal(letraKey))
                {
                    Console.WriteLine("Es una vocal");
                }
                else
                {
                    Console.WriteLine("Es consonante");
                }
            }

            Console.ReadKey();

        }

        public static bool EsNumero(char letra)
        {
            if(letra == '1' || letra == '2' || letra == '3' || letra == '4' ||
                letra == '5' || letra == '6' || letra == '7' || letra == '8' ||
                letra == '9' || letra == '0')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool EsVocal(char letra)
        {
            if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u' )
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
