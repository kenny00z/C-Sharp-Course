﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion9.Ejercicio1
{
    //Crea una Clase "Animal" que implemente la interfaz "IAnimal" , 
    //la interfaz "IAnimal" tendrá los métodos, Andar, es perro, saltar. 
    //implementa estos métodos en la clase. y usa esa clase en un programa de consola.
    class Program
    {
        static void Main(string[] args)
        {
            Animal animal = new Animal();

            animal.Andar();
        }
    }
}
