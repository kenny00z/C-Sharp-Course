﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion9.Ejercicio1
{
    public interface  IAnimal
    {
         bool EsPerro();
         void Andar();
         void Saltar();
    }
}
