﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion9.Ejercicio1
{
    public class Animal : IAnimal
    {
        public void Andar()
        {
            throw new NotImplementedException();
        }

        public bool EsPerro()
        {
            throw new NotImplementedException();
        }

        public void Saltar()
        {
            throw new NotImplementedException();
        }
    }
}
