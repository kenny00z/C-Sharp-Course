﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio1
{
    //Hacer un programa que transforme entre dólares 
    //y euros y que también pida el tipo de cambio del día.

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cuantos dolares es un euro (por ejemplo 0.89)");
            float cambio = float.Parse(Console.ReadLine());

            Console.Write("Cuantos euros tienes?");
            int euros = int.Parse(Console.ReadLine());

            Console.WriteLine($"Tienes {euros * cambio} dolares");
            Console.ReadKey();
        }
    }
}
