﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion6.Ejercicio5
{
    //Usando Arrays, crea un programa que nos pida cuantos elementos tendrá el array, 
    //dependiendo de ese numero de elementos, nos ira pidiendo valores, 
    //que introduciremos en el array. una vez introducidos, nos pedirá un nuevo valor a 
    //insertar y la posición donde queremos insertarla en el array.
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el numero de elementos del array");
            int elementos = int.Parse(Console.ReadLine());

            int[] arrayEnteros = new int[elementos];

            for (int i = 0; i < elementos; i++)
            {
                Console.WriteLine("Introduce un numero:");
                arrayEnteros[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("Introduce la posicion para cambiar el valor en array");
            int posicion = int.Parse(Console.ReadLine());

            Console.WriteLine("Introduce el nuevo valor");
            arrayEnteros[posicion + 1] = int.Parse(Console.ReadLine());

            for (int i = 0; i < elementos; i++)
            {
                Console.WriteLine(arrayEnteros[i]);
            }

            Console.ReadKey();
        }
    }
}
