﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion10.Ejercicio1
{
    //Crea un programa que use un diccionario, clave entera y valor string. 
    //Se pedirá por consola, un numero y un a cadena, que se ira insertando 
    //en el diccionario, hasta que se introduzca el valor "0". una vez se pulse "0",
    //se pedirá por pantalla que se introduzca una cadena.  
    //se mostrara consultando el diccionario, todas las claves que contienen ese valor 
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, string> diccionario = new Dictionary<int, string>();

            int numero = -1;

            while (numero != 0)
            {
                Console.WriteLine("Introduce un numero:");
                int num = int.Parse(Console.ReadLine());
                Console.WriteLine("Introduce un valor:");
                string valor = Console.ReadLine();

                diccionario.Add(num, valor);

                numero = num;
            }

            Console.WriteLine("Introduce un valor");
            var cadena = Console.ReadLine();

            if (diccionario.ContainsValue(cadena))
            {
                var coincidencias = diccionario.Where(x => x.Value.Contains(cadena));

                foreach (var item in coincidencias)
                {
                    Console.WriteLine(item.Value);
                }
            }

            Console.ReadKey();
        }
    }
}
