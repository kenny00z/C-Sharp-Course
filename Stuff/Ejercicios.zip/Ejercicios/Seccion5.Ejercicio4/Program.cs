﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion5.Ejercicio4
{
    //Escribir un programa que pida 4 números por consola, y escriba la siguiente frase, 
    //"El primer numero introducido es el <numero1> , despues han introducido el <numero2> y 
    //<numero3> y por ultimo el <numero4>"  utilizar StringBuilder para realizar el ejercicio.
    class Program
    {
        static void Main(string[] args)
        {

            StringBuilder sb = new StringBuilder();

            List<string> listCadenas = new List<string>();

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("introduce un numero");
                listCadenas.Add(Console.ReadLine());
            }

            sb.Append($"El primer numero introducido es el {listCadenas[0]} ,");
            sb.Append($"despues han introducido el {listCadenas[1]} y {listCadenas[2]}");
            sb.Append($" y por ultimo el {listCadenas[3]}");

            Console.WriteLine(sb.ToString());
            Console.ReadKey();
        }
    }
}
