﻿using System;

namespace Seccion2.Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("¿Cual es tu nombre?");
            string nombre = Console.ReadLine();
            Console.WriteLine("¿Cual es tu ciudad?");
            string ciudad = Console.ReadLine();
            Console.WriteLine("Hola " + nombre + " bienvenido a " + ciudad);
            Console.ReadKey();
        }
    }
}
