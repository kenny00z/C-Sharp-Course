﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion10.Ejercicio3
{
    public enum Animales
    {
        Perro = 5,
        Gato = 8,
        Canario = 2,
        Caballo = 12
    }
}
