﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion10.Ejercicio3
{
    public class Animal
    {
        public Animales TipoAnimal { get; set; }
        public string Nombre { get; set; }
    }
}
