﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion6.Ejercicio3
{
    //Pedir por pantalla 10 números, que iremos almacenando en un Listado (o 2 como prefiramos). al terminar de introducir los números, tendremos que recorrer 
    //el/los listados, diciéndonos cuanto suman los pares y cuando los impares.
    class Program
    {
        static void Main(string[] args)
        {
            List<int> pares = new List<int>();
            List<int> impares = new List<int>();
            int sumaPares = 0;
            int sumaImpares = 0;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Introduce un numero");
                int numero = int.Parse(Console.ReadLine());
                if (numero % 2 == 0)
                {
                    pares.Add(numero);
                }
                else
                {
                    impares.Add(numero);
                }
            }

            foreach (var numPares in pares)
            {
                sumaPares = sumaPares + numPares;
            }

            foreach (var numImpares in impares)
            {
                sumaImpares = sumaImpares + numImpares;
            }

            Console.WriteLine($"La suma de los pares es : {sumaPares}");
            Console.WriteLine($"La suma de los impares es : {sumaImpares}");

            Console.ReadKey();
        }
    }
}
