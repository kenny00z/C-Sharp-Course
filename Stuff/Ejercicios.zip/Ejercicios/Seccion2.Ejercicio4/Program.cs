﻿using System;

namespace Seccion2.Ejercicio4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("¿Cual es tu nombre?");
            string nombre = Console.ReadLine();
            Console.WriteLine("Hola " + nombre);
            Console.ReadKey();
        }
    }
}
