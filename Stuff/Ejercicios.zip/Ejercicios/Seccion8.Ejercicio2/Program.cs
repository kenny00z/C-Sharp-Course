﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio2
{
    //Desarrollar el ejercicio anterior, pero ahora al introducir el nombre, 
    //se especificara si es Alumno o Profesor, con lo que se crearan 2 clases nuevas 
    //que Heredaran ambas de "Persona". Si es Alumno, se pedirá el numero de alumno, 
    //si es profesor, se pedirá la materia que imparte.
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce el nombre");
            var nombre = Console.ReadLine();

            Console.WriteLine("Es alumno o profesor?");
            var tipo = Console.ReadLine();

            if(tipo == "alumno")
            {
                Alumno alumno = new Alumno();

                Console.WriteLine("introduce el numero de alumno");
                alumno.Nombre = nombre;
                alumno.NumeroAlumno = int.Parse(Console.ReadLine());

                Console.WriteLine($"Alumno {alumno.Nombre} con numero {alumno.NumeroAlumno}");
            }

            if (tipo == "profesor")
            {
                Profesor profesor = new Profesor();

                Console.WriteLine("introduce la materia que imparte");
                profesor.Nombre = nombre;
                profesor.MateriaImparte = Console.ReadLine();

                Console.WriteLine($"El profesor {profesor.Nombre} imparte {profesor.MateriaImparte}");
            }

            Console.ReadKey();
        }
    }
}
