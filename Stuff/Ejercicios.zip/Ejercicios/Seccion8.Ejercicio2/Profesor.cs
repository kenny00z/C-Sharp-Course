﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio2
{
    public class Profesor : Persona
    {
        public string MateriaImparte { get; set; }
    }
}
