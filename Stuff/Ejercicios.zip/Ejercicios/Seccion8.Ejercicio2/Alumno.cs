﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio2
{
    public class Alumno : Persona
    {
        public int NumeroAlumno { get; set; }
    }
}
