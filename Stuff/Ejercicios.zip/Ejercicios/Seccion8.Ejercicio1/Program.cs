﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio1
{
    //Desarrollar un programa que permita cargar 5 nombres de personas y 
    //sus edades respectivas. Luego de realizar la carga por teclado de todos 
    //los datos imprimir los nombres de las personas mayores de edad (mayores o iguales a 18 años)
    //, se tendrá que crear una clase "Persona" que contenga las propiedades "Nombre" y "Edad".
    //Utilizar todos los componentes vistos hasta la fecha (bucles, funciones, clases).
    class Program
    {
        static void Main(string[] args)
        {
            List<Persona> personas = new List<Persona>();

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine($"Introduce el nombre de la persona {i + 1}");
                var nombre = Console.ReadLine();

                Console.WriteLine($"Introduce la edad de la persona {i + 1}");
                var edad = int.Parse(Console.ReadLine());

                personas.Add(new Persona
                {
                    Nombre = nombre,
                    Edad = edad
                });
            }

            foreach (var persona in personas)
            {
                if (EsMayorDeEdad(persona))
                    Console.WriteLine($"Nombre: {persona.Nombre} Edad: {persona.Edad}");
            }

            Console.ReadKey();

        }

        public static bool EsMayorDeEdad(Persona persona)
        {
            if (persona.Edad >= 18)
                return true;

            return false;
        }
    }
}
