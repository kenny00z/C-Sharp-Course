﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion3.Ejercicio5
{
    class Program
    {
        //Recorre los números del 1 al 100. Usa un bucle for, pintarlos por consola.
      
        static void Main(string[] args)
        {
            for (int i = 1; i < 101; i++)
            {
                Console.WriteLine(i);
            }

            Console.ReadKey();
        }
    }
}
