﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio6
{
    //Crea un programa que este preguntando números por consola, hasta que se pulse el numero 0. una vez pulsado el 0 se mostrara la siguiente información: 

    //numero mas alto, numero mas bajo, la diferencia entre el mayor y el menor, cantidad de números introducidos

   //Usa métodos y funciones y el bucle While para controlar que se introduce el numero 0.
    class Program
    {
        static void Main(string[] args)
        {

            int numero = -1;
            int numeroMayor = 0;
            int numeroMenor = 10000;

            while (numero != 0)
            {

                Console.WriteLine("introduce un numero");
                int numeroIntroducido = int.Parse(Console.ReadLine());

                numero = numeroIntroducido;
                if(numero != 0)
                {
                    numeroMayor = EsMayor(numeroMayor, numeroIntroducido);
                    numeroMenor = EsMenor(numeroMenor, numeroIntroducido);
                }
            }

            Console.WriteLine($"Es numero mayor introducido es: {numeroMayor}");
            Console.WriteLine($"Es numero menor introducido es: {numeroMenor}");
            Console.ReadKey();
        }

        public static int EsMayor(int numeroMayor, int numeroIntroducido)
        {
            if (numeroIntroducido > numeroMayor)
                return numeroIntroducido;
            else
                return numeroMayor;
        }

        public static int EsMenor(int numeroMenor, int numeroIntroducido)
        {
            if (numeroIntroducido < numeroMenor)
                return numeroIntroducido;
            else
                return numeroMenor;
        }
    }
}
