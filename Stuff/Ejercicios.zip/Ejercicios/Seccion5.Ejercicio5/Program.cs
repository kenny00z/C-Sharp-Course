﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion5.Ejercicio5
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.Write("ABECEDARIO DESCENDENTE");
            Console.WriteLine();

            //Se recorren los numero de conversion de char segun su numero

            for (i = 90; i >= 65; i--)
            {
                Console.WriteLine("LETRA: " + Convert.ToString((char)i));
            }
            Console.Write("Pulse una Tecla:"); Console.ReadLine();
        }
    }
}
