﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion5.Ejercicio2
{
    //Escribir un programa que pida una palabra, y la escriba a su inversa , 
    //por ejemplo si se introduce Paris, devolverá "Sirap".
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un nombre");
            var nombre = Console.ReadLine();

            var nombreAlrevesArray = nombre.Reverse();

            string nombreAlReves = string.Empty;

            foreach (var item in nombreAlrevesArray)
            {
                nombreAlReves = nombreAlReves + item;
            }

            Console.WriteLine(nombreAlReves);
            Console.ReadKey();
        }
    }
}
