﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion6.Ejercicio2
{
    //Pedir por pantalla 5 nombres, e insertarlo en una Lista (List) una vez insertados, se pedirá que introduzcamos un nombre, 
    //el programa tendrá que decirnos, si ese nombre esta contenido en la lista.
    class Program
    {
        static void Main(string[] args)
        {
            List<string> listaNombres = new List<string>();
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Introduce un nombre:");
                listaNombres.Add(Console.ReadLine());
            }

            Console.WriteLine("Introduce otro nombre");
            var nombre = Console.ReadLine();

            if (listaNombres.Contains(nombre))
            {
                Console.WriteLine("Ese nombre esta contenido en el listado");
            }
            else
            {
                Console.WriteLine("Ese nombre NO esta contenido en el listado");
            }

            Console.ReadKey();
        }
    }
}
