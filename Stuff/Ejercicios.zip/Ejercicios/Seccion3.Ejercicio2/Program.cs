﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion3.Ejercicio2
{
    class Program
    {
        //Pedir dos números al usuario por teclado y decir que número es el mayor.

        static void Main(string[] args)
        {
            Console.WriteLine("Introduzca un numero");
            var numero1 = Console.ReadLine();
            Console.WriteLine("Introduzca otro numero");
            var numero2 = Console.ReadLine();

            //Como lo que viene de Console.Read es un string, hay que convertirlo en entero con int.Parse
            if(int.Parse(numero1) > int.Parse(numero2))
            {
                Console.WriteLine(numero1 + " es mayor que " + numero2);
            }
            else
            {
                Console.WriteLine(numero2 + " es mayor que " + numero1);
            }
        }
    }
}
