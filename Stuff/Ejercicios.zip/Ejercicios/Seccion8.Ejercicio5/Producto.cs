﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio5
{
    public class Producto
    {
        public static int SumaProductos(int producto1, int producto2)
        {
            return producto1 + producto2;
        }
    }
}
