﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio5
{
    //Crea una clase estática "Producto" , con un método estático , 
    //que sume 2 valores pasados por parámetro, úsalo desde otro lugar.
    class Program
    {
        static void Main(string[] args)
        {
            var suma = Producto.SumaProductos(3, 6);
        }
    }
}
