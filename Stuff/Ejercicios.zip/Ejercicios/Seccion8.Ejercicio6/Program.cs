﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio6
{
    //Crea una clase "Animal" con las siguientes propiedades: Tipo, color pelo,
    //es domestico, numero de patas, con el tipo de dato que creas conveniente. 
    //crea una instancia de esa clase, y asigna los valores a las propiedades.
    class Program
    {
        static void Main(string[] args)
        {
            Animal anima = new Animal
            {
                ColorPelo = "Rojo",
                EsDomestico = true,
                NumeroPatas = 4,
                Tipo = "Perro"
            };

            Animal animal2 = new Animal();
            animal2.ColorPelo = "Negro";
            animal2.EsDomestico = true;
            animal2.NumeroPatas = 4;
            animal2.Tipo = "Gato";
        }
    }
}
