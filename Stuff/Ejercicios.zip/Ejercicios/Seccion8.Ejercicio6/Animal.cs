﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio6
{
    public class Animal
    {
        public string Tipo { get; set; }
        public string ColorPelo { get; set; }
        public int NumeroPatas { get; set; }
        public bool EsDomestico { get; set; }
    }
}
