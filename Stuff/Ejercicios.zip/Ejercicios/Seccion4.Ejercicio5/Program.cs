﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion4.Ejercicio5
{
    //Crear un programa usando funciones, que introduciendo un número por consola,
    //pinte su tabla de multiplicar en la consola.
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un numero");
            int numero = int.Parse(Console.ReadLine());

            for (int i = 1; i < 21; i++)
            {
                Console.WriteLine($"{numero} x {i} = {DevuelveResultado(numero,i)}");
            }

            Console.ReadKey();
        }

        public static int DevuelveResultado(int numero, int indice)
        {
            return numero * indice;
        }
    }
}
