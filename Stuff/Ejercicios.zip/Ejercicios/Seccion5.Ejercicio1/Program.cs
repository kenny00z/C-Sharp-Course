﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion5.Ejercicio1
{
    //Crear un programa que pida al usuario su nombre, y le diga "Hola" si se 
    //llama "Alejandro", o bien le diga "No te conozco" si teclea otro nombre. 
    //tener en cuenta, que el la validación no es case sensitive, es decir que si 
    //escriben "alejandro" ,"Alejandro", "aleJANdrO" serán valores validos.
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un nombre");
            var nombre = Console.ReadLine();

            if(nombre.ToLower() == "alejandro")
            {
                Console.WriteLine("Hola");
            }
            else
            {
                Console.WriteLine("No te conozco");
            }

            Console.ReadKey();
        }
    }
}
