﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion5.Ejercicio3
{
//Crea un programa que pida una frase de al menos 20 caracteres y al menos 4 palabras por consola y se muestre la siguiente información de esa cadena(usa funciones para cada caso) , se deberá validar que la cadena tiene al menos 20 caracteres y la frase consta al menos de 4 palabras
//* longitud de la cadena
//* pinta la cadena, remplazando la letra "a" por "x", la "A" podrá ser mayúscula o minúscula en cuyo caso si es "a" se cambiara por una "x" y si es "A" se cambiara por una "X"
//* pinta la cadena en mayúsculas
//* pinta la cadena en minúsculas
//* pinta la cadena, removiendo las 3 primeras letras
//* pinta la cadena, extrayendo las letras en las posiciones de la 5 a la 10
//* escribe el numero de palabras que tiene la frase
//* escribe únicamente la tercera palabra

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce una frase con al menos 4 plabras y 20 caracteres de longitud");
            var frase = Console.ReadLine();

            if (CumpleValidacion(frase))
            {
                Console.WriteLine($"la longitud de la cadena es {frase.Length}");
                Console.WriteLine($"{frase.Replace("a","x").Replace("A","X")}");
                Console.WriteLine($"{frase.ToUpper()}");
                Console.WriteLine($"{frase.ToLower()}");
                Console.WriteLine($"{frase.Remove(0,3)}");
                Console.WriteLine($"{frase.Substring(5,5)}");
                Console.WriteLine($"la frase tiene {frase.Split(' ').Length} palabras");
                Console.WriteLine($"la tercera palabra es {frase.Split(' ')[2]}");
            }
            
        }

        public static bool CumpleValidacion(string frase)
        {
            if (frase.Length < 20 || frase.Split(' ').Length < 4)
            {
                Console.WriteLine("Tienes que introducir al menos 4 palabras y 20 caracteres de longitud");
                return false;
            }

            return true;
        }
    }
}
