﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio3
{
    public class Coche : Vehiculo
    {
        public override bool Circula(bool circula)
        {
            //siempre devuelve true, como cambio de la sobrecarga
            return true;
        }
    }
}
