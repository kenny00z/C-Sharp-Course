﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion8.Ejercicio3
{
    //Crear una Clase Base "Vehículo", y 3 clases derivadas de Vehículo, Coche, Barco, Avión,
    //crea unos métodos en vehículo, y sobrecargarlos en la clase derivada.
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
