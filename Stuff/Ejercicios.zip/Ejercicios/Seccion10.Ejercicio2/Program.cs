﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion10.Ejercicio2
{
    //Crear un programa que tenga una clase que acepte un tipo genérico. 
    //esa clase tendrá un método que ira añadiendo a un Listado de ese tipo, 
    //todos los valores introducidos por consola.
    class Program
    {
        static void Main(string[] args)
        {

            Ejemplo<int> ejemplo = new Ejemplo<int>();

            ejemplo.Add(5);
            ejemplo.Add(8);
            ejemplo.Add(12);

            foreach (var item in ejemplo.ObtenerValores())
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();


            Ejemplo<string> ejemplo2 = new Ejemplo<string>();

            ejemplo2.Add("valor 1");
            ejemplo2.Add("valor 2");
            ejemplo2.Add("valor 3");

            foreach (var item in ejemplo2.ObtenerValores())
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();

        }
    }
}
