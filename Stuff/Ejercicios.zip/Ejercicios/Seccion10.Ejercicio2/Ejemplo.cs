﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seccion10.Ejercicio2
{
    public class Ejemplo<T>
    {
        List<T> listado = new List<T>();

        public void Add(T valor)
        {
            listado.Add(valor);
        }

        public List<T> ObtenerValores()
        {
            return listado;
        }

    }
}
