﻿using CursoCSharp_3_abstraccion;
using System;

namespace CursoCSharp_3_tipos_datos_abstractos
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona persona = new Persona();
        }
    }
}
