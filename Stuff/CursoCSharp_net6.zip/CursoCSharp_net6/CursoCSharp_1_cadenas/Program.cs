﻿using System;

namespace CursoCSharp_1_cadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            string miCadena = "";
            string miCadena1 = string.Empty;
            string miCadena2 = "Hola Mundo!";

            int numero = 7;
            string numeroString = numero.ToString();

        }
    }
}
