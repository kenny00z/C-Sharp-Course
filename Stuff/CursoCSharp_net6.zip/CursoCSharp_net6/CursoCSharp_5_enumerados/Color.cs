﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_5_enumerados
{
    enum Color
    {
        Rojo,
        Verde,
        Azul
    }


    enum Alignment : int
    {
        Left = -1,
        Center = 0,
        Right = 1
    }

}
