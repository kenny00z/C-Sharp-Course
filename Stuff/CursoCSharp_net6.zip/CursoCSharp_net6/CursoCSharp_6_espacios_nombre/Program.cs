﻿using CursoCSharp_6_espacios_nombre.funcionalidad;
using System;

namespace CursoCSharp_6_espacios_nombre
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!");

            Console.WriteLine("Hello");
            Console.WriteLine("World!");


            Namespaces namespaces = new Namespaces();
        }
    }
}
