﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_6_espacios_nombre.funcionalidad
{
    public class Namespaces
    {
    }
}
