﻿using System;

namespace CursoCSharp_2_abstraccion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
