﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_3_cuerpo_clase
{
    class Clase
    {
        //Cuerpo

        //Constantes
        //Metodos
        //Propiedades
        //Eventos
        //Indizadores
        //Operadores
        //Contructores
        //Destructores
        //Tipos
    }
}
