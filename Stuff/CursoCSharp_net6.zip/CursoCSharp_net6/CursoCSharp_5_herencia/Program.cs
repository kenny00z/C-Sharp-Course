﻿using System;

namespace CursoCSharp_5_herencia
{
    class Program
    {
        static void Main(string[] args)
        {
            Point3D point3d = new Point3D();
            
        }
    }
}
