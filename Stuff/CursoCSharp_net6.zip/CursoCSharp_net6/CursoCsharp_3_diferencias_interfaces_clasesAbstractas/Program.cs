﻿using System;

namespace CursoCsharp_3_diferencias_interfaces_clasesAbstractas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
