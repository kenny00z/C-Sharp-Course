﻿using System;

namespace CursoCSharp_3_propiedades
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

    }
}
