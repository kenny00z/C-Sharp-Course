﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OtroNamespace.Ejemplo
{
    public class Namespace
    {
        public class MyClass
        {
            public override string ToString()
            {
                return "Estas en OtroNamespace.Ejemplo";
            }
        }

    }
}
