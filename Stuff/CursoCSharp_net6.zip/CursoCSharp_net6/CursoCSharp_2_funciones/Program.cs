﻿using System;

namespace CursoCSharp_2_funciones
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        //Procedimientos
        void Procedimiento()
        {
            Console.Write("Esto es un procedimiento");
        }

        //funciones
        int FuncionSuma()
        {
            return 7;
        }

        //Procedimientos de propiedades

        //Procedimientos de operador

    }
}
