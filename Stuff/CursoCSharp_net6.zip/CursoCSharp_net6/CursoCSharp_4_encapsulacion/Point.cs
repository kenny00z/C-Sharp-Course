﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_4_encapsulacion
{
    public class Point
    {

        public int X;
        public int Y;

    }
}
