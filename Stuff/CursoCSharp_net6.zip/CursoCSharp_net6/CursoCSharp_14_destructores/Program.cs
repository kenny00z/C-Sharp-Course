﻿using System;

namespace CursoCSharp_14_destructores
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
