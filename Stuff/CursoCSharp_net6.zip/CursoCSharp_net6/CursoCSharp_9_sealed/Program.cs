﻿using System;

namespace CursoCSharp_9_sealed
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
