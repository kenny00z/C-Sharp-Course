﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_9_sealed
{
    //public class Clase : ClaseSealed
    //{
    //    public string Nombre { get; set; }
    //}
}
