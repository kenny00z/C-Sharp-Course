﻿

namespace EjemploEF_net6.Models
{
    public class Cancion
    {
    }
}
