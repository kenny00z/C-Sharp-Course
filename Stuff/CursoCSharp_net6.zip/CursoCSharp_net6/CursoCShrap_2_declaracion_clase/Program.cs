﻿using System;

namespace CursoCShrap_2_declaracion_clase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
