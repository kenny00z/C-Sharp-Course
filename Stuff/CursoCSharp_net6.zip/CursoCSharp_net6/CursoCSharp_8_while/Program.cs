﻿using System;

namespace CursoCSharp_8_while
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 0;

            while(numero < 10)
            {
                Console.WriteLine(numero);
                numero++;
            }
        }
    }
}
