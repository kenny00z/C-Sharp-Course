﻿using System;

namespace CursoCSharp_metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        public void EstoEsUnMetod()
        {
            //código    
        }
    }
}
