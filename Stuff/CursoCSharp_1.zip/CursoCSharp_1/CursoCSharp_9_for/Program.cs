﻿using System;

namespace CursoCSharp_9_for
{
    class Program
    {
        static void Main(string[] args)
        {

            //int numero = 10;

            //for (int i = 0; i < numero; i++)
            //{
            //    Console.WriteLine(i);
            //}

            int numero2 = 0;

            for (int i = 10; i > numero2; i--)
            {
                
                Console.WriteLine(i);
            }

        }
    }
}
