﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_1_clases_estructuras
{
    public struct PointStruct
    {
        public int X { get; set; }
        public int Y { get; set; }


    }
}
