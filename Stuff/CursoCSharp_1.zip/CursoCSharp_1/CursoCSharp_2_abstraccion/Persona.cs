﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_2_abstraccion
{
    public class Persona
    {

        public int Edad { get; set; }
        public string Nacionalidad { get; set; }
        public string Ciudad { get; set; }
        public DateTime ColorPelo { get; set; }

    }
}
