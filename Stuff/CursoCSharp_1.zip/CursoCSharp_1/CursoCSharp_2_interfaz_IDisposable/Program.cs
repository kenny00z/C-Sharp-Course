﻿using System;

namespace CursoCSharp_2_interfaz_IDisposable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
