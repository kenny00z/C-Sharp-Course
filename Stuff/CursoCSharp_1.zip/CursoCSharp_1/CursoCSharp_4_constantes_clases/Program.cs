﻿using System;

namespace CursoCSharp_4_constantes_clases
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
