﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCShrap_2_declaracion_clase
{
    public class MyClase
    {

    }
}
