﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_6_poliformismo
{
    public abstract class Animal
    {
        public abstract void HacerRuido();
    }
}
