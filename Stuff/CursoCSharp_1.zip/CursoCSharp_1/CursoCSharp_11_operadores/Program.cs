﻿using System;

namespace CursoCSharp_11_operadores
{
    class Program
    {
        static void Main(string[] args)
        {
            var multiplicacion = 5 * 12;
            var suma = 5 + 6;
            var division = 10 / 5;
            var resto = 12 % 3;

            var esIgual = 5 == 5;
            var numero1 = 1;
            var numero2 = 10;

            if(numero1 == numero2)
            {

            }

            if(numero1 != numero2)
            {

            }

            if(numero1 < numero2)
            {

            }

            if(numero1 > numero2)
            {

            }

            if(numero1 >= numero2)
            {

            }

            if(numero1 <= numero2)
            {

            }

            if(numero1 == 5 && numero2 == 10)
            {

            }

            if(numero1 == 5 || numero2 == 10)
            {

            }

        }
    }
}
