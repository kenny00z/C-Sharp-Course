﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_1_clases_objetos
{
    public class CuentaBancaria
    {

        public int Saldo { get; set; }
        public bool Estado { get; set; }

        public static void Retirada()
        {

        }

        public static void Deposito()
        {
            
        }

        public static void MostrarSaldo()
        {
            Console.Write(1300);
        }
    }
}
