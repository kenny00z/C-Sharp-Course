﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_3_abstraccion
{
    public class Persona
    {

        public int Edad { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }

    }
}
