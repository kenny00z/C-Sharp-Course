﻿using System;

namespace CursoCSharp_3_cuerpo_clase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
