﻿using System;

namespace CursoCsharp_8_clases_abstractas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
