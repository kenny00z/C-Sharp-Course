﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_9_sealed
{
    public sealed class ClaseSealed
    {
        public int Edad { get; set; }
    }
}
