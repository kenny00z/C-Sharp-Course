﻿using System;

namespace CursoCSharp_1_interfaces
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
