﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoCSharp_5_herencia
{
    public interface IEjemplo
    {

        string Nombre { get; set; }

    }
}
