﻿using System;
using System.Collections;

namespace CursoCSharp_1_colecciones
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArrayList
            ArrayList lista = new ArrayList();

            //Pila o Stack
            Stack miPila = new Stack();

            //Cola o Queue
            Queue cola = new Queue();

            //Hastable
            Hashtable hastable = new Hashtable();
        }
    }
}
